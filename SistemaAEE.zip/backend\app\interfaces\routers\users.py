"""
Sistema AEE — Router: Usuários
================================
Responsabilidade única: traduzir HTTP → DTO → Use Case → Resposta HTTP.

[Clean Architecture]
- NENHUM repositório concreto é instanciado nos endpoints.
- NENHUMA lógica de negócio reside nos handlers.
- A tradução de DomainException → HTTPException está centralizada em _handle_domain_exception().
"""
import uuid

from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlmodel.ext.asyncio.session import AsyncSession

# ── Casos de Uso ──────────────────────────────────────────────────────────────
from app.application.use_cases.users.create_user import CreateUserInput, CreateUserUseCase
from app.application.use_cases.users.queries import (
    GetUserInput,
    GetUserUseCase,
    ListUsersInput,
    ListUsersUseCase,
)
from app.application.use_cases.users.toggle_user_status import (
    ToggleUserStatusInput,
    ToggleUserStatusUseCase,
)
from app.application.use_cases.users.update_profile import UpdateProfileInput, UpdateProfileUseCase
from app.application.use_cases.users.update_user import UpdateUserInput, UpdateUserUseCase

# ── Domínio ────────────────────────────────────────────────────────────────────
from app.domain.entities.user import PapelUsuario
from app.domain.exceptions import (
    DomainException,
    EmailJaEmUsoError,
    PermissaoInsuficienteError,
    TenantMismatchError,
    UsuarioNaoEncontradoError,
)

# ── Infraestrutura ─────────────────────────────────────────────────────────────
from app.infrastructure.database import get_session
from app.infrastructure.repositories.professor_assignment_repository_impl import (
    SQLModelProfessorAssignmentRepository,
)
from app.infrastructure.repositories.user_repository_impl import SQLModelUserRepository
from app.infrastructure.security.tokens import create_access_token
from app.infrastructure.services.email_service_impl import ConsoleEmailService
from app.infrastructure.unit_of_work_impl import SQLAlchemyUnitOfWork

# ── Interfaces ─────────────────────────────────────────────────────────────────
from app.interfaces.dependencies import CurrentUser, get_current_user
from app.interfaces.schemas.pagination import PaginatedResponse
from app.interfaces.schemas.user import (
    CreateUserRequest,
    ToggleStatusRequest,
    UpdateProfileRequest,
    UpdateProfileResponse,
    UpdateUserRequest,
    UserResponse,
)

router = APIRouter(prefix="/api/usuarios", tags=["usuarios"])

_DOMAIN_TO_HTTP: dict[type, int] = {
    UsuarioNaoEncontradoError: status.HTTP_404_NOT_FOUND,
    TenantMismatchError: status.HTTP_403_FORBIDDEN,
    PermissaoInsuficienteError: status.HTTP_403_FORBIDDEN,
    EmailJaEmUsoError: status.HTTP_409_CONFLICT,
}


def _handle_domain_exception(e: DomainException) -> None:
    status_code = _DOMAIN_TO_HTTP.get(type(e), status.HTTP_400_BAD_REQUEST)
    raise HTTPException(status_code=status_code, detail=str(e))


# ── Factories de Injeção de Dependências ──────────────────────────────────────

def get_create_user_use_case(session: AsyncSession = Depends(get_session)) -> CreateUserUseCase:
    return CreateUserUseCase(
        uow=SQLAlchemyUnitOfWork(session),
        user_repo=SQLModelUserRepository(session),
        email_service=ConsoleEmailService(),
        assignment_repo=SQLModelProfessorAssignmentRepository(session)
    )


def get_list_users_use_case(session: AsyncSession = Depends(get_session)) -> ListUsersUseCase:
    return ListUsersUseCase(user_repo=SQLModelUserRepository(session))


def get_get_user_use_case(session: AsyncSession = Depends(get_session)) -> GetUserUseCase:
    return GetUserUseCase(user_repo=SQLModelUserRepository(session))


def get_update_profile_use_case(session: AsyncSession = Depends(get_session)) -> UpdateProfileUseCase:
    return UpdateProfileUseCase(
        uow=SQLAlchemyUnitOfWork(session),
        user_repo=SQLModelUserRepository(session)
    )


def get_update_user_use_case(session: AsyncSession = Depends(get_session)) -> UpdateUserUseCase:
    return UpdateUserUseCase(
        uow=SQLAlchemyUnitOfWork(session),
        user_repo=SQLModelUserRepository(session),
        assignment_repo=SQLModelProfessorAssignmentRepository(session)
    )


def get_toggle_status_use_case(session: AsyncSession = Depends(get_session)) -> ToggleUserStatusUseCase:
    return ToggleUserStatusUseCase(
        uow=SQLAlchemyUnitOfWork(session),
        user_repo=SQLModelUserRepository(session),
        email_service=ConsoleEmailService()
    )


# ── Endpoints ─────────────────────────────────────────────────────────────────

@router.post("/", response_model=UserResponse, status_code=status.HTTP_201_CREATED)
async def create_user(
    request: CreateUserRequest,
    current_user: CurrentUser = Depends(get_current_user),
    use_case: CreateUserUseCase = Depends(get_create_user_use_case),
):
    input_dto = CreateUserInput(
        tenant_id=current_user.tenant_id,
        executor_papel=current_user.papel,
        email=request.email,
        password=request.password,
        nome=request.nome,
        papel=request.papel,
        escola_id=request.escola_id,
        aluno_ids=request.aluno_ids,
    )
    try:
        user = await use_case.execute(input_dto)
        return user
    except DomainException as e:
        _handle_domain_exception(e)
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )


@router.get("/", response_model=PaginatedResponse[UserResponse])
async def list_users(
    nome: str | None = Query(None, description="Filtrar por nome"),
    papel: PapelUsuario | None = Query(None, description="Filtrar por papel"),
    page: int = Query(1, ge=1, description="Número da página"),
    size: int = Query(50, ge=1, le=100, description="Tamanho da página"),
    current_user: CurrentUser = Depends(get_current_user),
    use_case: ListUsersUseCase = Depends(get_list_users_use_case),
):
    """Retorna usuários do mesmo tenant, com paginação e filtros opcionais."""
    try:
        input_dto = ListUsersInput(
            tenant_id=current_user.tenant_id,
            nome=nome,
            papel=papel,
            page=page,
            size=size
        )
        paginated_users = await use_case.execute(input_dto)
        return paginated_users
    except DomainException as e:
        _handle_domain_exception(e)


@router.get("/me", response_model=UserResponse)
async def get_me(
    current_user: CurrentUser = Depends(get_current_user),
    use_case: GetUserUseCase = Depends(get_get_user_use_case),
):
    """Retorna os dados do usuário autenticado atual, com seu papel validado."""
    try:
        input_dto = GetUserInput(user_id=current_user.id, tenant_id=current_user.tenant_id)
        return await use_case.execute(input_dto)
    except DomainException as e:
        _handle_domain_exception(e)


@router.patch("/me", response_model=UpdateProfileResponse)
async def update_my_profile(
    request: UpdateProfileRequest,
    current_user: CurrentUser = Depends(get_current_user),
    use_case: UpdateProfileUseCase = Depends(get_update_profile_use_case),
):
    """Atualiza os dados do perfil do usuário logado."""
    try:
        input_dto = UpdateProfileInput(
            user_id=current_user.id,
            tenant_id=current_user.tenant_id,
            nome=request.nome,
            email=request.email,
            escola_id=request.escola_id
        )
        updated_user = await use_case.execute(input_dto)

        # Gerar novo token com o nome atualizado
        access_token = create_access_token(
            user_id=updated_user.id,
            tenant_id=updated_user.tenant_id,
            papel=updated_user.papel.value,
            nome=updated_user.nome
        )

        return {
            "user": updated_user,
            "access_token": access_token
        }
    except DomainException as e:
        _handle_domain_exception(e)


@router.put("/{user_id}", response_model=UserResponse)
async def update_user(
    user_id: uuid.UUID,
    request: UpdateUserRequest,
    current_user: CurrentUser = Depends(get_current_user),
    use_case: UpdateUserUseCase = Depends(get_update_user_use_case),
):
    try:
        input_dto = UpdateUserInput(
            user_id_to_update=user_id,
            executor_papel=current_user.papel,
            tenant_id=current_user.tenant_id,
            nome=request.nome,
            papel=request.papel,
            escola_id=request.escola_id,
            aluno_ids=request.aluno_ids
        )
        return await use_case.execute(input_dto)
    except DomainException as e:
        _handle_domain_exception(e)


@router.patch("/{user_id}/status", status_code=status.HTTP_204_NO_CONTENT)
async def toggle_user_status(
    user_id: uuid.UUID,
    request: ToggleStatusRequest,
    current_user: CurrentUser = Depends(get_current_user),
    use_case: ToggleUserStatusUseCase = Depends(get_toggle_status_use_case),
):
    try:
        input_dto = ToggleUserStatusInput(
            user_id_to_toggle=user_id,
            executor_id=current_user.id,
            executor_papel=current_user.papel,
            tenant_id=current_user.tenant_id,
            novo_status=request.ativo
        )
        await use_case.execute(input_dto)
    except DomainException as e:
        _handle_domain_exception(e)


@router.get("/{user_id}/alunos", response_model=list[uuid.UUID])
async def get_user_alunos(
    user_id: uuid.UUID,
    current_user: CurrentUser = Depends(get_current_user),
    session: AsyncSession = Depends(get_session),
):
    """Retorna os IDs dos alunos atribuídos a este professor regente."""
    repo = SQLModelProfessorAssignmentRepository(session)
    assignments = await repo.list_active_by_user(user_id)
    return [a.aluno_id for a in assignments]
