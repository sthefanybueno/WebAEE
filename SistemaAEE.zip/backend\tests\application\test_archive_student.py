import uuid
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager

import pytest

from app.application.ports.unit_of_work import AbstractUnitOfWork
from app.application.use_cases.students.archive_student import (
    ArchiveStudentInput,
    ArchiveStudentUseCase,
)
from app.domain.entities.audit_log import AuditLog
from app.domain.entities.user import PapelUsuario
from app.domain.exceptions import (
    AlunoNaoEncontradoError,
)
from app.domain.models import StatusAluno, Student


class MockUnitOfWork(AbstractUnitOfWork):
    @asynccontextmanager
    async def transaction(self) -> AsyncIterator[None]:
        yield



class MockStudentRepository:
    def __init__(self) -> None:
        self.saved_students: dict[uuid.UUID, Student] = {}

    async def get_by_id(self, id: uuid.UUID, professor_id: uuid.UUID | None = None) -> Student | None:
        return self.saved_students.get(id)

    async def save(self, student: Student) -> Student:
        self.saved_students[student.id] = student
        return student


class MockAuditLogRepository:
    def __init__(self) -> None:
        self.logs: list[AuditLog] = []

    async def save(self, audit_log: AuditLog) -> AuditLog:
        self.logs.append(audit_log)
        return audit_log


@pytest.fixture
def repo_student() -> MockStudentRepository:
    return MockStudentRepository()


@pytest.fixture
def repo_audit() -> MockAuditLogRepository:
    return MockAuditLogRepository()


@pytest.mark.asyncio
async def test_archive_student_success(
    repo_student: MockStudentRepository, repo_audit: MockAuditLogRepository
) -> None:
    # Given
    student_id = uuid.uuid4()
    tenant_id = uuid.uuid4()
    user_id = uuid.uuid4()

    student = Student(
        id=student_id,
        nome="José",
        tenant_id=tenant_id,
        consentimento_lgpd=True,
    )
    repo_student.saved_students[student_id] = student

    use_case = ArchiveStudentUseCase(uow=MockUnitOfWork(), student_repo=repo_student, audit_repo=repo_audit)
    input_dto = ArchiveStudentInput(
        student_id=student_id,
        tenant_id=tenant_id,
        user_id=user_id,
        papel=PapelUsuario.ADMIN,
    )

    # When
    updated_student = await use_case.execute(input_dto)

    # Then

    assert updated_student.status == StatusAluno.ARQUIVADO
    assert updated_student.updated_by == user_id

    assert len(repo_audit.logs) == 1
    assert repo_audit.logs[0].student_id == student_id
    assert repo_audit.logs[0].user_id == user_id
    assert repo_audit.logs[0].field_accessed == "status (arquivamento)"


@pytest.mark.asyncio
async def test_archive_student_not_found(
    repo_student: MockStudentRepository, repo_audit: MockAuditLogRepository
) -> None:
    # Given
    use_case = ArchiveStudentUseCase(uow=MockUnitOfWork(), student_repo=repo_student, audit_repo=repo_audit)
    input_dto = ArchiveStudentInput(
        student_id=uuid.uuid4(),
        tenant_id=uuid.uuid4(),
        user_id=uuid.uuid4(),
        papel=PapelUsuario.ADMIN,
    )
    
    # When / Then
    with pytest.raises(AlunoNaoEncontradoError):
        await use_case.execute(input_dto)
