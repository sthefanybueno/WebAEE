import uuid
from datetime import UTC, datetime

from sqlmodel import Field, SQLModel


def _utcnow() -> datetime:
    return datetime.now(UTC).replace(tzinfo=None)


class StudentSchoolHistoryORM(SQLModel, table=True):
    __tablename__ = "student_school_history"  # type: ignore[assignment]

    id: uuid.UUID = Field(default_factory=uuid.uuid4, primary_key=True)
    student_id: uuid.UUID = Field(nullable=False, index=True)
    school_id: uuid.UUID = Field(nullable=False, index=True)
    user_id: uuid.UUID = Field(nullable=False, description="Quem transferiu")
    transfer_date: datetime = Field(default_factory=_utcnow, nullable=False)
